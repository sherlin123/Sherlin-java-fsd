package projectphase1;
abstract class AnonymousInnnerClass {
	   public abstract void display();
	}


	public class innerClass3 {

	public static void main(String[] args) {
	AnonymousInnnerClass i = new AnonymousInnnerClass() {

	         public void display() {
	            System.out.println("Anonymous Inner Class");
	         }
	      };
	      i.display();
	   }
	}
