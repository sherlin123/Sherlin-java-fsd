package projectphase1;
public class multiplicationmethod {

public int multipynumbers(int a,int b) {
	int z=a*b;
	return z;
}

public static void main(String[] args) {

	multiplicationmethod b=new multiplicationmethod();
	int ans= b.multipynumbers(5,3);
	System.out.println("Multipilcation is :"+ans);
	}}
