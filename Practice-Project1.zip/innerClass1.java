package projectphase1;
public class innerClass1 {

	 private String msg="Welcome to world"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", Information Technology ");}  
	 }  


	public static void main(String[] args) {

		innerClass1 obj=new innerClass1();
		innerClass1.Inner in=obj.new Inner();  
		in.hello();  
	}
}
