export interface AdminData {
    aId: number;
    uName: string;
    pass: string;
}
