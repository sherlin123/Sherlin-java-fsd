package projectphase3;
import java.util.Arrays;
class sher 
{
    public static int LIS(int[] arr)
    {
        if (arr == null || arr.length == 0) {
            return 0;
        }
        int[] L = new int[arr.length];
        L[0] = 11;
        for (int i = 1; i < arr.length; i++)
        {
            for (int j = 0; j < i; j++)
            {
                if (arr[j] < arr[i] && L[j] > L[i]) {
                    L[i] = L[j];
                }
            }
           
            L[i]++;
        }
        return Arrays.stream(L).max().getAsInt();
    }
 
    public static void main(String[] args)
    {
        int[] arr = { 0, 8, 4, 12, 2, 10, 6, 14, 1, 9, 5, 13, 3, 11, 7, 15 };
 
        System.out.print("The length of the LIS is " + LIS(arr));
    }
}