package miniproject;
public class Main {
	
	
	public static final String path = "C:\\Users\\HP\\Documents\\simplilearn"; 
	
	public static void main(String[] args) {
		Mainlist menu = new Mainlist();
		menu.introScreen();
		menu.mainMenu();
	}
	
}